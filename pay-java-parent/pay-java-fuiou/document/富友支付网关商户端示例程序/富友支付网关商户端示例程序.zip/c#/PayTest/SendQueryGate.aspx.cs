﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using Fuiou.PayTest;

public partial class SendQueryGate : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    /// <summary>
    /// 到富友查询订单支付结果
    /// </summary>
    protected void SendPostData()
    {
        #region 数据基础
        string mchnt_cd = System.Configuration.ConfigurationManager.AppSettings["mchnt_no"];
        string order_id = orderid.Value;                                        //订单编号
        if (string.IsNullOrEmpty(order_id.Trim()))
        {
            order_id = StrRandom(20);
            orderid.Value = order_id;
        }


        string postData = "mchnt_cd=" + mchnt_cd;                         //商户代码
        postData += "&order_id=" + order_id;                                    //订单日期
        postData += "&page_notify_url=" + page_notify_url.Value;                //页面跳转URL
        postData += "&back_notify_url=" + back_notify_url.Value;                //后台通知URL
        string mchnt_key = System.Configuration.ConfigurationManager.AppSettings["mchnt_key"];                 //32位的商户密钥，系统分配
        #endregion

        #region 数据处理
        string MD5Str = mchnt_cd + "|" + order_id + "|" + page_notify_url.Value + "|" + back_notify_url.Value + "|" + mchnt_key;

        //调用MD5加密
        string md5 = Fuiou.PayTest.Security.SecurityService.Encrypt(MD5Str, Fuiou.PayTest.Security.SymmProvEnum.MD5);

        postData += "&md5=" + md5;
        #endregion

        #region 数据发送
        //到配置文件取到URL,并且post数据至该地址
        string url = System.Configuration.ConfigurationManager.AppSettings["SendQueryGateURL"];
        string getdate = PostData.PostDataToUrl(postData, url);

        Response.Clear();
        Response.Write(getdate);

        #endregion

    }

    /// <summary>
    /// 输出一个随机数
    /// </summary>
    /// <param name="num">随机数位数</param>
    /// <returns></returns>
    public string StrRandom(int num)
    {
        string number = "";
        Random ran = new Random();
        for (int i = 0; i < num; i++)
        {
            number += ran.Next(9).ToString();
        }
        return number;
    }

    protected void btnSumbit_Click(object sender, EventArgs e)
    {
        SendPostData();
    }
}