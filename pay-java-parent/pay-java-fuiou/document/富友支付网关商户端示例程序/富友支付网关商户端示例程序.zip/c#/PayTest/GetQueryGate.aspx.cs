﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GetQueryGate : System.Web.UI.Page
{
    /// <summary>
    /// 接收富友反馈查询结果(订单交易查询结果)
    /// </summary>
    protected void Page_Load(object sender, EventArgs e)
    {
        string mchnt_cd = lblmchnt_cd.Text = Request["mchnt_cd"];                       //商户代码
        string order_id = lblorder_id.Text = Request["order_id"];                       //商户订单号
        string order_date = lblorder_date.Text = Request["order_date"];                 //订单日期
        string order_amt = lblorder_amt.Text = Request["order_amt"];                    //交易金额
        string order_st = lblorder_st.Text = Request["order_st"];                       //订单状态
        string order_pay_code = lblorder_pay_code.Text = Request["order_pay_code"];     //错误代码
        string order_pay_error = lblorder_pay_error.Text = Request["order_pay_error"];  //错误中文描述
        string fy_ssn = lblfy_ssn.Text = Request["fy_ssn"];                             //富友流水号
        string md5 = lblmd5.Text = Request["md5"];                                      //MD5摘要数据
        string resv1 = lblresv1.Text = Request["resv1"];                                //保留字段
        string mchnt_key = System.Configuration.ConfigurationManager.AppSettings["mchnt_key"];            //32位的商户密钥，系统分配

        string str = mchnt_cd + "|" + order_id + "|" + order_date + "|" + order_amt + "|" + order_st + "|" +
   order_pay_code + "|" + order_pay_error + "|" + resv1 + "|" + fy_ssn + "|" + mchnt_key;
        if (!string.IsNullOrEmpty(md5))
        {
            lblMD5Check.Text = Fuiou.PayTest.Security.SecurityService.Encrypt(str, Fuiou.PayTest.Security.SymmProvEnum.MD5).ToLower() == md5.ToLower() ? "MD5匹配" : "MD5不匹配 返回数据非法";
        }
        else
        {
            lblMD5Check.Text = "MD5不匹配 返回数据非法";
        }
    }
}