﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Fuiou.PayTest;
using System.Text;


public partial class SendOrder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    /// <summary>
    /// 发送订单数据到富友
    /// </summary>
    protected void SendPostData()
    {
        #region 数据基础

        string mchnt_cd = System.Configuration.ConfigurationManager.AppSettings["mchnt_no"];//商户号
        order_id.Value = StrRandom(20);                                          //订单号(目前测试为随机)
        string mchnt_key = System.Configuration.ConfigurationManager.AppSettings["mchnt_key"];           // //32位的商户密钥，系统分配
        string MD5Str = mchnt_cd + "|" + order_id.Value + "|" + order_amt.Value + "|" + order_pay_type.Value + "|"
            + page_notify_url.Value + "|" + back_notify_url.Value + "|" + order_valid_time.Value + "|"
            + iss_ins_cd.Value + "|" + goods_name.Value + "|" + goods_display_url.Value + "|" + mchnt_key;//加密前字符串

        //调用MD5加密
        string md5 = Fuiou.PayTest.Security.SecurityService.Encrypt(MD5Str, Fuiou.PayTest.Security.SymmProvEnum.MD5);//加密后得到的MD5
    
        #endregion

        #region 数据发送

        //到配置文件取到URL,并且post数据至该地址
        string url = System.Configuration.ConfigurationManager.AppSettings["SendOrderURL"];
      
        StringBuilder sb = new StringBuilder();
        sb.Append("<form name='fuiousubmit' method='post' action='" + url + "'>");
        sb.Append("<input type='hidden' name='mchnt_cd' value='" + mchnt_cd + "'>");
        sb.Append("<input type='hidden' name='order_id' value='" + order_id.Value + "'>");
        sb.Append("<input type='hidden' name='order_amt' value='" + order_amt.Value + "'>");
        sb.Append("<input type='hidden' name='order_pay_type' value='" + order_pay_type.Value + "'>");
        sb.Append("<input type='hidden' name='page_notify_url' value='" + back_notify_url.Value + "'>");
        sb.Append("<input type='hidden' name='back_notify_url' value='" + back_notify_url.Value + "'>");
        sb.Append("<input type='hidden' name='order_valid_time' value='" + order_valid_time.Value + "'>");
        sb.Append("<input type='hidden' name='iss_ins_cd' value='" + iss_ins_cd.Value+ "'>");
        sb.Append("<input type='hidden' name='goods_name' value='" + goods_name.Value + "'>");
        sb.Append("<input type='hidden' name='goods_display_url' value='" + goods_display_url.Value + "'>");
        sb.Append("<input type='hidden' name='md5' value=" + md5 + ">");
        sb.Append("</form>");
        sb.Append("<script>");
        sb.Append("document.fuiousubmit.submit()");
        sb.Append("</script>");

        System.Web.HttpContext.Current.Response.Write(sb.ToString());

        #endregion
    }

    /// <summary>
    /// 输出一个随机数
    /// </summary>
    /// <param name="num">随机数位数</param>
    /// <returns></returns>
    public string StrRandom(int num)
    {
        string number = "";
        Random ran = new Random();
        for (int i = 0; i < num; i++)
        {
            number += ran.Next(9).ToString();
        }
        return number;
    }

    protected void btnSumbit_Click(object sender, EventArgs e)
    {
        SendPostData();
    }
}