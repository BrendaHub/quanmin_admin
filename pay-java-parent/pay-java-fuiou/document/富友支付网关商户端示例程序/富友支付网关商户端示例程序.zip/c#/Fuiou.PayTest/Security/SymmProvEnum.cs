using System;
using System.Collections.Generic;
using System.Text;

namespace Fuiou.PayTest.Security
{
    public enum SymmProvEnum
    {
        DES,
        RC2,
        Rijndael,
        TripleDES,
        MD5,
        SHA1
    }
}
