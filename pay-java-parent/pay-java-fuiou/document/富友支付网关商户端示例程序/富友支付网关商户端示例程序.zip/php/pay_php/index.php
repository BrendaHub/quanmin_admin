<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="styles/style.css" rel="stylesheet" type="text/css" />
<title>XXX商城</title>
<style type="text/css">
table{ 
	margin:0 auto; 
} 
</style>
</head>

<body>
<!--top -->
<br />
<form name="tempForm" method="post">
<table width="70%" cellspacing="0" border="0" cellspacing="1" >
	  <tr> 
			<td class="info_title" >操作</td>
	  </tr>
	  
	  <tr>
	   <td width="100%"> 
		<table width="100%" border="0" cellspacing="1">

			<tr>
				<td width="200" class="bg_gray" align="right" >1、&nbsp;&nbsp;</td>
				<td align="left">&nbsp;&nbsp;<a href="<?php webAppPath ?>order.php">订单支付</a></td>
			</tr>
			<tr>
				<td width="200" class="bg_gray" align="right" >2、&nbsp;&nbsp;</td>
				<td align="left">&nbsp;&nbsp;<a href="<?php webAppPath ?>query.php">订单查询</a></td>
			</tr>
			<tr>
				<td width="200" class="bg_gray" align="right" >3、&nbsp;&nbsp;</td>
				<td align="left">&nbsp;&nbsp;<a href="<?php webAppPath ?>refund.php">订单退款</a></td>
			</tr>
		</table>
	   </td>
	  </tr>
	</table>
</form>
</body>
</html>

