<?php

class StringUtils {
	
    function nvl($aStr) {
        if($aStr==null)
        	return "";
        else
        	return $aStr;
    }
}
